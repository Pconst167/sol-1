/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : ethernet.c
* Last version	: 1.00
* Description	: This file is source file for ethernet control(w5300)
*
* History
* Date		    Version	    Author			Description
* 07/16/2011	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ----------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include "uart.h"
#include "stm32f10x.h"
#include "socket.h"
#include "types.h"
#include "typedef.h"
#include "ethernet.h"
#include "stm32f10x_fsmc.h"

/* Privated variables ------------------------------------------------------*/
extern POINT DispPoint;
extern u16 FontColor, BgColor;

/*****************************************************************************
* Descriptions  : W5300 �ʱ�ȭ
* Parameters    : None
* Return Value  : None
*****************************************************************************/
static void W5300_Init(void)
{
    FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
    FSMC_NORSRAMTimingInitTypeDef  p;
    GPIO_InitTypeDef GPIO_InitStructure; 
    
    /* Enable FSMC, GPIOD, GPIOE, GPIOF, GPIOG and AFIO clocks */
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE |
                            RCC_APB2Periph_GPIOF | RCC_APB2Periph_GPIOG |
                            RCC_APB2Periph_AFIO, ENABLE);  
    
    /*-- GPIO Configuration ------------------------------------------------------*/
    /*!< W5300 Data lines configuration */
    /*!< NOE and NWE configuration */  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5 |
                            GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_14 | 
                            GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);   
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | 
                            GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | 
                            GPIO_Pin_15;
    GPIO_Init(GPIOE, &GPIO_InitStructure);  
    
    /*!< W5300 Address lines configuration */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                            GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_12 | GPIO_Pin_13 | 
                            GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_Init(GPIOF, &GPIO_InitStructure);
              
    /*!< NE2 configuration */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; 
    GPIO_Init(GPIOG, &GPIO_InitStructure);
        
    /*-- FSMC Configuration ------------------------------------------------------*/
    p.FSMC_AddressSetupTime = 16;
    p.FSMC_AddressHoldTime = 0;
    p.FSMC_DataSetupTime = 16;
    p.FSMC_BusTurnAroundDuration = 0;
    p.FSMC_CLKDivision = 0;
    p.FSMC_DataLatency = 0;
    p.FSMC_AccessMode = FSMC_AccessMode_A;
    
    FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM2;
    FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
    FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
    FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
    FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
    //FSMC_NORSRAMInitStructure.FSMC_AsynchronousWait = FSMC_AsynchronousWait_Disable;  
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
    FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
    FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &p;
    FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &p;
    FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure);  
    /* BANK 2 (of NOR/SRAM Bank 1~4) is enabled */
    FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM2, ENABLE);                  
}


/*****************************************************************************
* Descriptions  : �̴��� �ʱ�ȭ
* Parameters    : IP address, Gateway address, Subnet mask, Physical address
* Return Value  : None
*****************************************************************************/
void EthernetInit(void)
{
    uint8 tx_mem_conf[8] = {8,8,8,8,8,8,8,8};
    uint8 rx_mem_conf[8] = {8,8,8,8,8,8,8,8};       
    
    //uint8 ip[4] = {168,115,105,51};                         // for setting SIP register
    uint8 ip[4] = {192,168,1,100};                         // for setting SIP register

    uint8 gw[4] = {168,115,104,1};                          // for setting GAR register
    //uint8 sn[4] = {255,255,252,0};                          // for setting SUBR register
    uint8 sn[4] = {255,255,255,0};                          // for setting SUBR register

    uint8 mac[6] = {0x00,0x08,0xDC,0x11,0x22,0x86};         // for setting SHAR register           
            
    // initial W5300
    W5300_Init();
    // initiate W5300
    iinchip_init();
    
    // allocate internal TX/RX Memory of W5300
    if(!sysinit(tx_mem_conf,rx_mem_conf))           
    {
        vPrintf(UART1_SERIAL, "MEMORY CONFIG ERR.\r\n");
        while(1);
    }
    
    setMR(getMR()|MR_FS);            
    setSHAR(mac);                                      // set source hardware address
    
#ifdef __DEF_IINCHIP_PPP__
    if(pppinit((uint8*)"test01", 6, (uint8*)"pppoe1000", 9)!=1)
    {
        vPrintf(UART1_SERIAL, "PPPoE fail.\r\n");
        while(1);
    }
    close(0);
#else
    // configure network information
    setGAR(gw);                                     // set gateway IP address
    setSUBR(sn);                                    // set subnet mask address
    setSIPR(ip);                                    // set source IP address
#endif              
}

/*****************************************************************************
* Descriptions  : �̴��� ���� ǥ��
* Parameters    : IP address, Gateway address, Subnet mask, Physical address
* Return Value  : None
*****************************************************************************/
void DispEthernetInfo(void)
{
    uint8 ip[4];
    uint8 gw[4];
    uint8 sn[4];
    uint8 mac[6];
    
    getSHAR(mac);   // get source hardware address 
    getGAR(gw);     // get gateway IP address      
    getSUBR(sn);    // get subnet mask address     
    getSIPR(ip);    // get source IP address       
    vPrintf(UART1_SERIAL, "Network Setting Information\r\n");  
    vPrintf(UART1_SERIAL, "Physical Address : %02x:%02x:%02x:%02x:%02x:%02x\r\n", mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
    vPrintf(UART1_SERIAL, "Gateway Address  : %d.%d.%d.%d\r\n",gw[0],gw[1],gw[2],gw[3]);
    vPrintf(UART1_SERIAL, "Subnet Mask      : %d.%d.%d.%d\r\n",sn[0],sn[1],sn[2],sn[3]);
    vPrintf(UART1_SERIAL, "IP Address       : %d.%d.%d.%d\r\n",ip[0],ip[1],ip[2],ip[3]);                   
}

/**
 * "TCP SERVER" loopback program.
 */ 
void LoopbackTcps(SOCKET s, uint16 port, uint8* buf, uint16 mode)
{
    uint32 len;
    
    switch(getSn_SSR(s))                    // check SOCKET status
    {                                       // ------------
        case SOCK_ESTABLISHED:              // ESTABLISHED?
            if(getSn_IR(s) & Sn_IR_CON)     // check Sn_IR_CON bit
            {
                vPrintf(UART1_SERIAL, "%d : Connect OK\r\n",s);
                setSn_IR(s,Sn_IR_CON);      // clear Sn_IR_CON
            }
            if((len=getSn_RX_RSR(s)) > 0)   // check the size of received data
            {
                len = recv(s,buf,len);      // recv                                   
                if(len !=send(s,buf,len))   // send
                {
                    vPrintf(UART1_SERIAL, "%d : Send Fail.len=%d\r\n",s,len);
                }
                
                if(len>70) *(buf+70) = '\0';
                else *(buf+len) = '\0';
                
                vPrintf(UART1_SERIAL, "TCP Socket(%d) Port(%d): %s\r\n", s, port, buf);
            }
            break;
        // ---------------
        case SOCK_CLOSE_WAIT:               // PASSIVE CLOSED
            disconnect(s);                  // disconnect 
            break;
        // --------------
        case SOCK_CLOSED:                   // CLOSED
            close(s);                       // close the SOCKET
            socket(s,Sn_MR_TCP,port,mode);  // open the SOCKET  
            break;
        // ------------------------------
        case SOCK_INIT:                     // The SOCKET opened with TCP mode
            listen(s);                      // listen to any connection request from "TCP CLIENT"
            vPrintf(UART1_SERIAL, "%d : LOOPBACK_TCPS(%d) Started.\r\n",s,port);
            break;
        default:
            break;
    }
}

/**
 * "TCP CLIENT" loopback program.
 */ 
void LoopbackTcpc(SOCKET s, uint8* addr, uint16 port, uint8* buf, uint16 mode)
{
    uint32 len;
    static uint16 any_port = 1000;
    
    switch(getSn_SSR(s))                            // check SOCKET status
    {                                               // ------------
        case SOCK_ESTABLISHED:                      // ESTABLISHED?
            if(getSn_IR(s) & Sn_IR_CON)             // check Sn_IR_CON bit
            {
                vPrintf(UART1_SERIAL, "%d : Connect OK\r\n",s);
                setSn_IR(s,Sn_IR_CON);              // clear Sn_IR_CON
            }
            if((len=getSn_RX_RSR(s)) > 0)           // check the size of received data
            {
                len = recv(s,buf,len);              // recv
                if(len !=send(s,buf,len))           // send
                {
                    vPrintf(UART1_SERIAL, "%d : Send Fail.len=%d\r\n",s,len);
                }
            }
            break;
            // ---------------
        case SOCK_CLOSE_WAIT:                       // PASSIVE CLOSED
            disconnect(s);                          // disconnect 
            break;
            // --------------
        case SOCK_CLOSED:                           // CLOSED
            close(s);                               // close the SOCKET
            socket(s,Sn_MR_TCP,any_port++,mode);    // open the SOCKET with TCP mode and any source port number
            break;
            // ------------------------------
        case SOCK_INIT:                             // The SOCKET opened with TCP mode
            connect(s, addr, port);                 // Try to connect to "TCP SERVER"
            vPrintf(UART1_SERIAL, "%d : LOOPBACK_TCPC(%d.%d.%d.%d:%d) Started.\r\n",s,addr[0],addr[1],addr[2],addr[3],port);
            break;
        default:
            break;
    }
}

/**
 * UDP loopback program.
 */ 
void LoopbackUdp(SOCKET s, uint16 port, uint8* buf, uint16 mode)
{
    uint32 len;
    uint8 destip[4];
    uint16 destport;
    
    switch(getSn_SSR(s))
    {
        // -------------------------------
        case SOCK_UDP:                                      // 
            if((len=getSn_RX_RSR(s)) > 0)                   // check the size of received data
            {
                len = recvfrom(s,buf,len,destip,&destport); // receive data from a destination
                if(len !=sendto(s,buf,len,destip,destport)) // send the data to the destination
                {
                    vPrintf(UART1_SERIAL, "%d : Sendto Fail.len=%d,",s,len);
                    vPrintf(UART1_SERIAL, "%d.%d.%d.%d(%d)\r\n",destip[0],destip[1],destip[2],destip[3],destport);
                }
                                
                if(len>70) *(buf+70) = '\0';
                else *(buf+len) = '\0';
                
                vPrintf(UART1_SERIAL, "UDP Socket(%d) Port(%d): %s\r\n", s, port, buf);

            }
            break;
        // -----------------
        case SOCK_CLOSED:                                   // CLOSED
            close(s);                                       // close the SOCKET
            socket(s,Sn_MR_UDP,port,mode);                  // open the SOCKET with UDP mode
            break;
        default:
            break;
    }
}                
