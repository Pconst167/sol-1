**Made for personal projects. USE AT YOUR OWN RISK!**

Optosupply LEDs for KiCad.

**Made for personal projects. USE AT YOUR OWN RISK!**
